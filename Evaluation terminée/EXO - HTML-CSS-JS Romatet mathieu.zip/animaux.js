var animaux = [
  {
    name: "ours",
    domestic: false,
    file: "bear.png",
  },
  {
    name: "zebre",
    domestic: false,
    file: "zebra.png",
  },
  {
    name: "chat",
    domestic: true,
    file: "chat.png",
  },
  {
    name: "chien",
    domestic: true,
    file: "chien.png",
  },
  {
    name: "cheval",
    domestic: true,
    file: "cheval.png",
  },
  {
    name: "hippopotame",
    domestic: false,
    file: "hippo.png",
  },
  {
    name: "cat",
    domestic: true,
    file: "cat.png",
  },
  {
    name: "giraffe",
    domestic: false,
    file: "giraffe.png",
  },
  {
    name: "monkey",
    domestic: false,
    file: "monkey.png",
  },
  {
    name: "tiger",
    domestic: false,
    file: "tiger.png",
  },
];
